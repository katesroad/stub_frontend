import * as React from 'react'

export default function TicketsScreen() {
  return (
    <div>
      <h4>Tickets list</h4>
    </div>
  )
}
