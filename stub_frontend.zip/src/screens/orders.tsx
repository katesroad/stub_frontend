import * as React from 'react'

export default function OrdersScreen() {
  return (
    <div>
      <h4>Order list</h4>
    </div>
  )
}
