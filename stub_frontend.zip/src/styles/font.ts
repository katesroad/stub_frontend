// setup the font-family, font-weight

export const font: Record<string, string> = {}