const c1 = 'red'
const c2 = '#7e3af2'
const c3 = '#8f939b'
const c4 = '#6aff79'
const c5 = '#575D69'
const c6 = '#DADBDE'

export const colors = { c1, c2, c3, c4, c5, c6 }
