export const small = "@media (min-width: 576px)";
export const medium = "@media (min-width: 768px)";
export const large = "@media(min-width:992px)";
export const xlarge = "@media(min-width:1200px)";
