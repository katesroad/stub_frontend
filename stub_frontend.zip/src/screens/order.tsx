import * as React from 'react'

export default function OrderScreen() {
  return (
    <div>
      <h4>Order Detail</h4>
    </div>
  )
}
