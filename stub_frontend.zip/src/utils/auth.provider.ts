export function renewToken() {
  return Promise.resolve(true)
}
